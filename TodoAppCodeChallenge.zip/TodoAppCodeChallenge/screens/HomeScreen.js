import React from 'react'
import { Button, StyleSheet, View, Text, FlatList } from 'react-native'
import { store } from "../store/rootStore"
export default function HomeScreen({ navigation }) {

  const handleNavigation = () => {
    navigation.navigate("AddTask")
  }

  const handleDelete = () => {
    // borrar

  }
  return (
    <View style={styles.container}>


      <FlatList
        data={store.getTasks()}
        renderItem={({ item }) => <View>
          <Text>{(item.name)}</Text>
          <Button title='delete' onPress={handleDelete} />
        </View>
        }
      />
      <Button
        // Navegar a agrear una nueva tarea
        onPress={handleNavigation}
        title='AddTask'
      />
    </View>
  )
}
// lista de todos

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16
  }
})
