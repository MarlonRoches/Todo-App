import React, {useState} from 'react'
import { Button, View, StyleSheet, TextInput, Text } from 'react-native'
import { store } from "../store/rootStore"

export default function AddTaskScreen({ route, navigation }) {
  const handleNavigation = () => {
    navigation.goBack();
  }
  const handleCreate = () => {
    store.addNew(
      taskName,
      false
    )
  }

  const [taskName, setTaskName] = useState('')
  return (
    <View style={styles.container}>
      <Text>
        Titulo
      </Text>
      <TextInput placeholder='Crear Tarea' onChange={setTaskName} />
      <Button
        // navegar de regreso
        onPress={handleCreate}
        title='Crear'
      />
    </View>
  )
}

// // crear nuevas task
// const textInputStyle : = {

// }

const styles = StyleSheet.create({
  container: {

    flex: 1,
    padding: 16,
    paddingTop: 40
  },
})
