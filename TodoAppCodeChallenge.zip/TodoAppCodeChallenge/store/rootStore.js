// todo: name, completed
let tasks = [
  {
    id:0,
    name: 'example',
    completed: true
  },
  {
    id:1,
    name: 'example',
    completed: true
  },
]

class Task {
  getInstance() {
    return this;
  }

  getCount() {
    return tasks.length;
  }
  getTasks() {
    return tasks
  }
  addNew(name, completed){
    tasks.push({id:tasks.length, name, completed})
  }
}

export const store = new Task();
