export interface TaskType {
    name: string,
    completed: boolean,
} 